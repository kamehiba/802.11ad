#ifndef __SENS_LUT__
#define __SENS_LUT__

namespace ns3 {

double sensitivity_ber(unsigned int index);

}

#endif /* __SENS_LUT__ */
